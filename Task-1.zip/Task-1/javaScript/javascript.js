// Selectors
const todoForm = document.getElementById('todo-form');
const todoInput = document.getElementById('todo-input');
const todoList = document.getElementById('todo-list');

// Event listeners
todoForm.addEventListener('submit', addTodo);
todoList.addEventListener('click', handleTodoClick);

// Functions
function addTodo(event) {
    event.preventDefault();

    const todoText = todoInput.value.trim(); 
    if (todoText.length === 0) return; 
    const todoItem = document.createElement('li');
    todoItem.textContent = todoText;

    const editButton = document.createElement('button');
    editButton.textContent = 'Edit';
    editButton.classList.add('edit-button');

    const removeButton = document.createElement('button');
    removeButton.textContent = 'Remove';
    removeButton.classList.add('remove-button');

    todoItem.appendChild(editButton);
    todoItem.appendChild(removeButton);

    todoList.appendChild(todoItem);

    todoInput.value = ''; 
}

function handleTodoClick(event) {
    const clickedItem = event.target;

    if (clickedItem.classList.contains('edit-button')) {
        editTodoItem(clickedItem.parentElement);
    } else if (clickedItem.classList.contains('remove-button')) {
        removeTodoItem(clickedItem.parentElement);
    }
}

function editTodoItem(todoItem) {
    const currentText = todoItem.firstChild.textContent;
    const newText = prompt('Edit task:', currentText);

    if (newText !== null && newText.trim() !== '') {
        todoItem.firstChild.textContent = newText.trim();
    }
}

function removeTodoItem(todoItem) {
    todoItem.remove();
}
